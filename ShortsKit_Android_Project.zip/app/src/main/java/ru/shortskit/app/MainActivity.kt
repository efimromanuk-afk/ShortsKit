package ru.shortskit.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF10111B)
private val Panel = Color(0xFF1B1D2B)
private val Purple = Color(0xFFA78BFA)
private val Cyan = Color(0xFF67E8F9)
private val Soft = Color(0xFFB8BCD0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ShortsKitApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShortsKitApp(context: Context) {
    var topic by remember { mutableStateOf("") }
    var audience by remember { mutableStateOf("") }
    var platform by remember { mutableStateOf("YouTube Shorts") }
    var style by remember { mutableStateOf("Интрига") }
    var result by remember { mutableStateOf("") }
    var expandedPlatform by remember { mutableStateOf(false) }
    var expandedStyle by remember { mutableStateOf(false) }

    val platforms = listOf("YouTube Shorts", "VK Клипы", "Дзен", "Rutube", "TikTok")
    val styles = listOf("Интрига", "Топ / список", "Полезный совет", "История", "Миф или правда")

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            secondary = Cyan,
            background = Night,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF211B3A), Night, Night))
            )
        ) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(50.dp).background(
                            Brush.linearGradient(listOf(Purple, Cyan)),
                            RoundedCornerShape(16.dp)
                        ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("S", color = Night, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("ShortsKit", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text("Помощник для коротких видео", color = Soft, fontSize = 13.sp)
                    }
                }

                Text("Придумай следующий ролик", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Создавай заготовки заголовков, сценариев, описаний и хештегов.",
                    color = Soft, lineHeight = 21.sp
                )

                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = topic, onValueChange = { topic = it.take(120) },
                            label = { Text("Тема видео") },
                            placeholder = { Text("Например: лайфхаки для телефона") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = false
                        )
                        OutlinedTextField(
                            value = audience, onValueChange = { audience = it.take(100) },
                            label = { Text("Для кого? (необязательно)") },
                            placeholder = { Text("Новички, студенты, геймеры") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            singleLine = true
                        )
                        ExposedDropdownMenuBox(
                            expanded = expandedPlatform,
                            onExpandedChange = { expandedPlatform = !expandedPlatform }
                        ) {
                            OutlinedTextField(
                                value = platform, onValueChange = {}, readOnly = true,
                                label = { Text("Платформа") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expandedPlatform) },
                                modifier = Modifier.menuAnchor().fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp)
                            )
                            ExposedDropdownMenu(expanded = expandedPlatform,
                                onDismissRequest = { expandedPlatform = false }) {
                                platforms.forEach { item ->
                                    DropdownMenuItem(text = { Text(item) }, onClick = {
                                        platform = item; expandedPlatform = false
                                    })
                                }
                            }
                        }
                        ExposedDropdownMenuBox(
                            expanded = expandedStyle,
                            onExpandedChange = { expandedStyle = !expandedStyle }
                        ) {
                            OutlinedTextField(
                                value = style, onValueChange = {}, readOnly = true,
                                label = { Text("Стиль") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expandedStyle) },
                                modifier = Modifier.menuAnchor().fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp)
                            )
                            ExposedDropdownMenu(expanded = expandedStyle,
                                onDismissRequest = { expandedStyle = false }) {
                                styles.forEach { item ->
                                    DropdownMenuItem(text = { Text(item) }, onClick = {
                                        style = item; expandedStyle = false
                                    })
                                }
                            }
                        }
                        Button(
                            onClick = {
                                if (topic.isBlank()) {
                                    Toast.makeText(context, "Сначала введи тему видео", Toast.LENGTH_SHORT).show()
                                } else {
                                    result = generateContent(topic.trim(), audience.trim(), platform, style)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Night)
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Создать идею", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (result.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Твой набор для ролика", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Text(result, lineHeight = 22.sp)
                            Spacer(Modifier.height(14.dp))
                            OutlinedButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("ShortsKit", result))
                                    Toast.makeText(context, "Текст скопирован", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Копировать всё")
                            }
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Первая версия", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Работает без регистрации и интернета. Генерация основана на шаблонах. Реклама пока не подключена.",
                            color = Soft, lineHeight = 20.sp
                        )
                    }
                }
                Text(
                    "ShortsKit не гарантирует просмотры или популярность. Проверяй факты и редактируй сценарии перед публикацией.",
                    color = Soft, fontSize = 12.sp, lineHeight = 17.sp
                )
            }
        }
    }
}

private fun generateContent(topic: String, audience: String, platform: String, style: String): String {
    val titles = when (style) {
        "Топ / список" -> listOf(
            "3 вещи о «$topic», которые пригодятся каждому",
            "Топ-5 фактов о «$topic» за 30 секунд",
            "3 ошибки в теме «$topic», которые легко исправить"
        )
        "Полезный совет" -> listOf(
            "Как разобраться с «$topic» за 30 секунд",
            "Простой способ улучшить результат в теме «$topic»",
            "Сохрани: короткая инструкция по теме «$topic»"
        )
        "История" -> listOf(
            "Я проверил идею про «$topic» — вот что вышло",
            "Одна ошибка в теме «$topic» изменила всё",
            "История о «$topic», из которой можно кое-что взять"
        )
        "Миф или правда" -> listOf(
            "Миф или правда: что на самом деле с «$topic»?",
            "Правда ли это про «$topic»? Проверим",
            "Не верь каждому совету о «$topic»: вот почему"
        )
        else -> listOf(
            "Ты удивишься, но вот что важно знать про «$topic»",
            "Большинство пропускает эту деталь в теме «$topic»",
            "Что будет, если попробовать это с «$topic»?"
        )
    }
    val title = titles.random()
    val audienceLine = if (audience.isBlank()) "" else "\nАудитория: $audience."
    val tags = topic.lowercase()
        .split(Regex("[^\\p{L}\\p{N}]+"))
        .filter { it.length > 2 }
        .take(3).joinToString(" ") { "#$it" }
    return """ПЛАТФОРМА
$platform

ЗАГОЛОВОК
$title

ЗАЦЕПКА И СЦЕНАРИЙ
1. Начни с вопроса или неожиданного факта о теме «$topic».
2. Объясни тему на конкретном примере.
3. Дай один полезный вывод и попроси зрителя поделиться мнением.

ОПИСАНИЕ
$topic — коротко, понятно и по делу.$audienceLine
Напиши в комментариях, какую тему разобрать следующей.

ХЕШТЕГИ
${listOf(tags, "#shorts", "#советы", "#интересное").filter { it.isNotBlank() }.joinToString(" ")}"""
}
